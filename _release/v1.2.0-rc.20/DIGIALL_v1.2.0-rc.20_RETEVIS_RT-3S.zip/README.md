# Retevis RT-3S compatible board · v1.2.0-rc.20

**ZIP 只是打包文件，不能直接刷入电台。先解压，CPS 每次只选择一份 BIN。**

## 完整安装：按顺序分别刷写 3 次

1. 进入本机 DFU，用桌面 OpenGD77 CPS 刷 `01_font_*.bin`。正常开机运行字库写入器，看到 `COMPLETE - VERIFIED` 并等待背光熄灭后关机；显示 FAILED 时停止。
2. 重新进入 DFU，刷 `02_pinyin_*.bin`。正常开机运行拼音写入器，看到 `COMPLETE - VERIFIED` 并等待背光熄灭后关机。
3. 再次进入 DFU，刷 `03_main_*.bin`。完成后松开按键，正常开机使用电台。

01/02 是临时资源写入器，不是日常运行固件，不能停在这两步。若误刷 ZIP 或停在写入器后循环重启，请关机后重新进入 DFU，按上述三步完成安装，最后必须刷 03_main。

已确认本项目兼容字库和拼音资源完整的升级，可只更新 03_main；首次安装或资源状态不明时完成全部三步。

ZIP is packaging only. Extract it first; load one BIN at a time in desktop CPS. Full installation requires three separate flashes: 01_font → 02_pinyin → 03_main. Run each resource writer to COMPLETE - VERIFIED before switching off and re-entering DFU. Finish with 03_main; the resource writers are temporary, not the final firmware.

先核对板型，再按下面的实际文件名操作。

[中文安装与测试](docs/MULTI_MODEL_TESTING.zh-CN.md) · [English installation and testing](docs/MULTI_MODEL_TESTING.en.md)

1. `01_font_RETEVIS_RT-3S_v1.2.0-rc.20.bin`
2. `02_pinyin_RETEVIS_RT-3S_v1.2.0-rc.20.bin`
3. `03_main_RETEVIS_RT-3S_v1.2.0-rc.20.bin`
