# Retevis RT-84 · v1.2.0-rc.17

先核对板型，按完整说明用 OpenGD77 CPS 安装。

[中文安装与测试](docs/MULTI_MODEL_TESTING.zh-CN.md) · [English installation and testing](docs/MULTI_MODEL_TESTING.en.md)

1. `01_font_RETEVIS_RT-84_v1.2.0-rc.17.bin`
2. `02_pinyin_RETEVIS_RT-84_v1.2.0-rc.17.bin`
3. `03_main_RETEVIS_RT-84_v1.2.0-rc.17.bin`
